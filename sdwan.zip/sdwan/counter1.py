#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from myCounter import myTaskCounter
def main():
    taskid = myTaskCounter()
    print(next(taskid))
    pass

if __name__ == '__main__':
    main()

from ipaddress import ip_address
def isValidIP(ipStr=None):
    if ipStr is None:
        return False
    if "/" in ipStr:
        # ip address also have netmask check number must be in range 1..32
        # slip and trim
        (ip,mask) = ipStr.split("/")
        try:
            ip = ip.strip() # remove white spaces from ip and mask
            mask = int(mask.strip())
##            print(mask)
            if 8 <= mask <= 32:
##                print(ip)
                ip_address(ip)
                return True
            else:
                return False
        except ValueError:
            return False
    try:
        ip_address(ipStr)
        return True
    except ValueError:
        return False

def checkIPStr(ipStr=None):
    if ipStr is None:
        return False
    if "," in ipStr:
        l = ipStr.split(",")
        for item in l:
            if not isValidIP(item):
                return False
        return True
    elif not isValidIP(ipStr): # could be a single IP
        return False
    else:
        return True

def ipPrefix(ipStr=None):
    if ipStr is None:
        return None
    if not checkIPStr(ipStr):
        return None
    else: # create list of ipPrefix
        prefixList = []
        l = ipStr.split(",")
        for item in l:
            prefixList.append( {"ipPrefix": item} )
        return prefixList

def dataPrefixPayload(name, desc=None, objType="dataprefix", ipStr=None):
    if ipStr is None:
        return None
    prefixList = ipPrefix(ipStr=ipStr)
    if prefixList is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"dataprefix",\
            "entries": prefixList
            }
